package com.webmotion.bibleamplifiee.data

import android.content.Context

class PreferenceStore(context: Context) {
    private val prefs = context.getSharedPreferences("bible_prefs", Context.MODE_PRIVATE)

    var darkMode: Boolean
        get() = prefs.getBoolean("dark_mode", true)
        set(value) = prefs.edit().putBoolean("dark_mode", value).apply()

    var fontScale: Float
        get() = prefs.getFloat("font_scale", 1f)
        set(value) = prefs.edit().putFloat("font_scale", value).apply()

    var displayMode: String
        get() = prefs.getString("display_mode", "FR") ?: "FR"
        set(value) = prefs.edit().putString("display_mode", value).apply()

    fun favorites(): Set<String> = prefs.getStringSet("favorites", emptySet())?.toSet().orEmpty()

    fun toggleFavorite(ref: VerseRef): Boolean {
        val set = favorites().toMutableSet()
        val added = if (set.contains(ref.key)) {
            set.remove(ref.key)
            false
        } else {
            set.add(ref.key)
            true
        }
        prefs.edit().putStringSet("favorites", set).apply()
        return added
    }
}
