package com.webmotion.bibleamplifiee

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webmotion.bibleamplifiee.ui.theme.BibleTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: BibleViewModel = viewModel()
            val dark = vm.darkMode.collectAsStateWithLifecycle().value
            BibleTheme(darkTheme = dark) {
                BibleApp(vm)
            }
        }
    }
}
