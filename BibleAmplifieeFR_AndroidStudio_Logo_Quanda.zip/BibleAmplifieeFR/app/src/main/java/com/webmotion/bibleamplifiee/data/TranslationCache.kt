package com.webmotion.bibleamplifiee.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TranslationCache(context: Context) : SQLiteOpenHelper(context, "bible_translation.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE translations (
                book INTEGER NOT NULL,
                chapter INTEGER NOT NULL,
                verse INTEGER NOT NULL,
                text_fr TEXT NOT NULL,
                PRIMARY KEY(book, chapter, verse)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_translation_text ON translations(text_fr)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun get(ref: VerseRef): String? {
        readableDatabase.query(
            "translations", arrayOf("text_fr"),
            "book=? AND chapter=? AND verse=?",
            arrayOf(ref.book.toString(), ref.chapter.toString(), ref.verse.toString()),
            null, null, null, "1"
        ).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun getChapter(book: Int, chapter: Int): Map<Int, String> {
        val map = linkedMapOf<Int, String>()
        readableDatabase.query(
            "translations", arrayOf("verse", "text_fr"),
            "book=? AND chapter=?", arrayOf(book.toString(), chapter.toString()),
            null, null, "verse ASC"
        ).use { c ->
            while (c.moveToNext()) map[c.getInt(0)] = c.getString(1)
        }
        return map
    }

    fun put(ref: VerseRef, textFr: String) {
        val values = ContentValues().apply {
            put("book", ref.book)
            put("chapter", ref.chapter)
            put("verse", ref.verse)
            put("text_fr", textFr)
        }
        writableDatabase.insertWithOnConflict("translations", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun searchFrench(query: String, limit: Int = 100): List<Pair<VerseRef, String>> {
        val result = mutableListOf<Pair<VerseRef, String>>()
        readableDatabase.query(
            "translations", arrayOf("book", "chapter", "verse", "text_fr"),
            "text_fr LIKE ?", arrayOf("%$query%"), null, null,
            "book, chapter, verse", limit.toString()
        ).use { c ->
            while (c.moveToNext()) {
                result += VerseRef(c.getInt(0), c.getInt(1), c.getInt(2)) to c.getString(3)
            }
        }
        return result
    }
}
