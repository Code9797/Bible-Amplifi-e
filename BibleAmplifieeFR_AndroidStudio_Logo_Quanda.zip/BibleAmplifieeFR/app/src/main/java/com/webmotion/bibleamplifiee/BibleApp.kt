package com.webmotion.bibleamplifiee

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.webmotion.bibleamplifiee.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BibleApp(vm: BibleViewModel) {
    val screen by vm.screen.collectAsStateWithLifecycle()
    val books by vm.books.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val selectedBook by vm.selectedBook.collectAsStateWithLifecycle()
    val chapter by vm.chapter.collectAsStateWithLifecycle()
    val translations by vm.translations.collectAsStateWithLifecycle()
    val status by vm.translationStatus.collectAsStateWithLifecycle()
    val displayMode by vm.displayMode.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()

    BackHandler(enabled = screen == Screen.READER) { vm.navigate(Screen.HOME) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (screen) {
                            Screen.HOME -> "Quanda Bible Amplifiée"
                            Screen.READER -> selectedBook?.let { "${it.nameFr} $chapter" } ?: "Lecture"
                            Screen.SEARCH -> "Recherche"
                            Screen.FAVORITES -> "Favoris"
                            Screen.SETTINGS -> "Réglages"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (screen == Screen.READER) {
                        IconButton(onClick = { vm.navigate(Screen.HOME) }) {
                            Icon(Icons.Default.ArrowBack, "Retour")
                        }
                    }
                },
                actions = {
                    if (screen == Screen.READER) {
                        IconButton(onClick = vm::speakCurrentChapter) { Icon(Icons.Default.VolumeUp, "Écouter") }
                        IconButton(onClick = vm::stopSpeech) { Icon(Icons.Default.Stop, "Arrêter") }
                    }
                }
            )
        },
        bottomBar = {
            if (screen != Screen.READER) {
                NavigationBar {
                    NavItem(screen, Screen.HOME, "Bible", Icons.Default.MenuBook, vm)
                    NavItem(screen, Screen.SEARCH, "Recherche", Icons.Default.Search, vm)
                    NavItem(screen, Screen.FAVORITES, "Favoris", Icons.Default.Favorite, vm)
                    NavItem(screen, Screen.SETTINGS, "Réglages", Icons.Default.Settings, vm)
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                screen == Screen.HOME -> HomeScreen(books, vm::openBook)
                screen == Screen.READER && selectedBook != null -> ReaderScreen(
                    book = selectedBook!!,
                    chapterNumber = chapter,
                    translations = translations,
                    status = status,
                    displayMode = displayMode,
                    favorites = favorites,
                    fontScale = fontScale,
                    onChapter = vm::setChapter,
                    onMode = vm::setDisplayMode,
                    onFavorite = vm::toggleFavorite,
                    onSpeak = vm::speakVerse
                )
                screen == Screen.SEARCH -> SearchScreen(vm)
                screen == Screen.FAVORITES -> FavoritesScreen(vm)
                screen == Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(current: Screen, target: Screen, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, vm: BibleViewModel) {
    NavigationBarItem(
        selected = current == target,
        onClick = { vm.navigate(target) },
        icon = { Icon(icon, label) },
        label = { Text(label) }
    )
}

@Composable
private fun HomeScreen(books: List<BibleBook>, onBook: (BibleBook, Int) -> Unit) {
    var testament by remember { mutableStateOf(Testament.OLD) }
    val visible = books.filter { it.testament == testament }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logo_quanda_bible),
                        contentDescription = "Logo Quanda Bible Amplifiée",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(20.dp)),
                        contentScale = ContentScale.Fit
                    )
                    Text("BIBLE AMPLIFIÉE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("Interface française • 66 livres • 1 189 chapitres • 31 102 versets")
                    Text(
                        "Traduction française automatique sur l’appareil, avec conservation du texte anglais original.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(testament == Testament.OLD, { testament = Testament.OLD }, { Text("Ancien Testament") })
                FilterChip(testament == Testament.NEW, { testament = Testament.NEW }, { Text("Nouveau Testament") })
            }
        }
        items(visible, key = { it.number }) { book ->
            Card(onClick = { onBook(book, 1) }, modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(book.nameFr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("${book.chapters.size} chapitre${if (book.chapters.size > 1) "s" else ""}", style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
    }
}

@Composable
private fun ReaderScreen(
    book: BibleBook,
    chapterNumber: Int,
    translations: Map<Int, String>,
    status: String,
    displayMode: DisplayMode,
    favorites: Set<String>,
    fontScale: Float,
    onChapter: (Int) -> Unit,
    onMode: (DisplayMode) -> Unit,
    onFavorite: (VerseRef) -> Unit,
    onSpeak: (Int) -> Unit
) {
    val chapter = book.chapters.first { it.number == chapterNumber }
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(book.chapters, key = { it.number }) { c ->
                FilterChip(selected = c.number == chapterNumber, onClick = { onChapter(c.number) }, label = { Text(c.number.toString()) })
            }
        }

        Row(
            Modifier.padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(displayMode == DisplayMode.FR, { onMode(DisplayMode.FR) }, { Text("Français") })
            FilterChip(displayMode == DisplayMode.BILINGUAL, { onMode(DisplayMode.BILINGUAL) }, { Text("FR + EN") })
            FilterChip(displayMode == DisplayMode.EN, { onMode(DisplayMode.EN) }, { Text("English") })
        }
        Text(status, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chapter.verses, key = { it.number }) { verse ->
                val ref = VerseRef(book.number, chapterNumber, verse.number)
                VerseCard(
                    verse = verse,
                    french = translations[verse.number],
                    ref = ref,
                    isFavorite = favorites.contains(ref.key),
                    displayMode = displayMode,
                    fontScale = fontScale,
                    onFavorite = { onFavorite(ref) },
                    onSpeak = { onSpeak(verse.number) }
                )
            }
            item {
                Text(
                    "Source anglaise : Amplified Bible (copyright indiqué dans le fichier XML fourni). La version française affichée ici est une traduction automatique locale et n’est pas une édition officielle publiée.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun VerseCard(
    verse: BibleVerse,
    french: String?,
    ref: VerseRef,
    isFavorite: Boolean,
    displayMode: DisplayMode,
    fontScale: Float,
    onFavorite: () -> Unit,
    onSpeak: () -> Unit
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(34.dp).clip(RoundedCornerShape(50)),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(verse.number.toString(), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onSpeak) { Icon(Icons.Default.VolumeUp, "Écouter") }
                IconButton(onClick = onFavorite) {
                    Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favori")
                }
            }

            if (displayMode != DisplayMode.EN) {
                Text(
                    french ?: "Traduction française en cours…",
                    fontSize = (18f * fontScale).sp,
                    lineHeight = (28f * fontScale).sp,
                    fontWeight = FontWeight.Medium
                )
            }
            if (displayMode != DisplayMode.FR) {
                Text(
                    verse.textEn,
                    fontSize = (15f * fontScale).sp,
                    lineHeight = (23f * fontScale).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SearchScreen(vm: BibleViewModel) {
    val results by vm.searchResults.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Mot, expression ou verset") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            trailingIcon = {
                IconButton(onClick = { vm.search(query) }) { Icon(Icons.Default.Search, "Rechercher") }
            }
        )
        Text("La recherche française couvre les chapitres déjà traduits et mis en cache.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results, key = { it.ref.key }) { hit ->
                SearchHitCard(hit, onClick = { vm.openRef(hit.ref) })
            }
        }
    }
}

@Composable
private fun FavoritesScreen(vm: BibleViewModel) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val hits = remember(favorites, vm.books.value) { vm.favoriteHits() }
    if (hits.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Aucun verset favori") }
    } else {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(hits, key = { it.ref.key }) { hit -> SearchHitCard(hit) { vm.openRef(hit.ref) } }
        }
    }
}

@Composable
private fun SearchHitCard(hit: SearchHit, onClick: () -> Unit) {
    Card(onClick = onClick, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${hit.bookName} ${hit.ref.chapter}:${hit.ref.verse}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            hit.french?.let { Text(it, maxLines = 4) }
            Text(hit.english, style = MaterialTheme.typography.bodySmall, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsScreen(vm: BibleViewModel) {
    val dark by vm.darkMode.collectAsStateWithLifecycle()
    val scale by vm.fontScale.collectAsStateWithLifecycle()
    val mode by vm.displayMode.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text("Affichage", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Mode sombre", Modifier.weight(1f))
                Switch(dark, vm::setDarkMode)
            }
        }
        item {
            Text("Taille du texte : ${(scale * 100).toInt()} %")
            Slider(value = scale, onValueChange = vm::setFontScale, valueRange = 0.85f..1.5f)
        }
        item {
            Text("Langue de lecture", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(mode == DisplayMode.FR, { vm.setDisplayMode(DisplayMode.FR) }, { Text("Français") })
                FilterChip(mode == DisplayMode.BILINGUAL, { vm.setDisplayMode(DisplayMode.BILINGUAL) }, { Text("FR + EN") })
                FilterChip(mode == DisplayMode.EN, { vm.setDisplayMode(DisplayMode.EN) }, { Text("English") })
            }
        }
        item {
            HorizontalDivider()
            Text("À propos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text(
                "Bible Amplifiée FR utilise le fichier XML anglais fourni avec l’application. Le modèle ML Kit anglais → français est téléchargé au premier besoin puis les traductions de versets sont enregistrées dans SQLite pour une lecture ultérieure hors ligne."
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Important : la traduction française générée est automatique. Pour une publication publique ou commerciale, vérifiez les droits de redistribution du texte source Amplified Bible et les conditions de la source fournie.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
