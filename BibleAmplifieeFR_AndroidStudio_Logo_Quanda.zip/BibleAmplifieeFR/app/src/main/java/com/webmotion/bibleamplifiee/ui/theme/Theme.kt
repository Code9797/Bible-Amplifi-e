package com.webmotion.bibleamplifiee.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Gold = Color(0xFFD6A84B)
private val DarkScheme = darkColorScheme(
    primary = Gold,
    secondary = Color(0xFFE8C875),
    background = Color(0xFF0D0D0F),
    surface = Color(0xFF17171B),
    surfaceVariant = Color(0xFF24242A),
    onPrimary = Color(0xFF201900)
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFF8A6500),
    secondary = Color(0xFF705D22),
    background = Color(0xFFFFFBF4),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFF4EEE1)
)

@Composable
fun BibleTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = Typography(),
        content = content
    )
}
