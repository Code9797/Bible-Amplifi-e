package com.webmotion.bibleamplifiee.translation

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class BibleTextToSpeech(context: Context) {
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.language = Locale.FRENCH
                tts?.setSpeechRate(0.88f)
            }
        }
    }

    fun speak(text: String, id: String = "verse") {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        engine.language = Locale.FRENCH
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun speakChapter(lines: List<String>) {
        val engine = tts ?: return
        if (!ready) return
        engine.stop()
        engine.language = Locale.FRENCH
        lines.filter { it.isNotBlank() }.forEachIndexed { index, line ->
            engine.speak(line, TextToSpeech.QUEUE_ADD, null, "chapter_$index")
        }
    }

    fun stop() { tts?.stop() }
    fun close() { tts?.shutdown(); tts = null }
}
