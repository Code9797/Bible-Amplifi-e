package com.webmotion.bibleamplifiee

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webmotion.bibleamplifiee.data.*
import com.webmotion.bibleamplifiee.translation.BibleTextToSpeech
import com.webmotion.bibleamplifiee.translation.FrenchTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { HOME, READER, SEARCH, FAVORITES, SETTINGS }
enum class DisplayMode { FR, BILINGUAL, EN }

class BibleViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = BibleRepository(app)
    private val cache = TranslationCache(app)
    private val prefs = PreferenceStore(app)
    private val translator = FrenchTranslator()
    private val tts = BibleTextToSpeech(app)
    private var translationJob: Job? = null

    private val _books = MutableStateFlow<List<BibleBook>>(emptyList())
    val books: StateFlow<List<BibleBook>> = _books.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen.asStateFlow()

    private val _selectedBook = MutableStateFlow<BibleBook?>(null)
    val selectedBook: StateFlow<BibleBook?> = _selectedBook.asStateFlow()

    private val _chapter = MutableStateFlow(1)
    val chapter: StateFlow<Int> = _chapter.asStateFlow()

    private val _translations = MutableStateFlow<Map<Int, String>>(emptyMap())
    val translations: StateFlow<Map<Int, String>> = _translations.asStateFlow()

    private val _translationStatus = MutableStateFlow("Prêt")
    val translationStatus: StateFlow<String> = _translationStatus.asStateFlow()

    private val _displayMode = MutableStateFlow(runCatching { DisplayMode.valueOf(prefs.displayMode) }.getOrDefault(DisplayMode.FR))
    val displayMode: StateFlow<DisplayMode> = _displayMode.asStateFlow()

    private val _darkMode = MutableStateFlow(prefs.darkMode)
    val darkMode: StateFlow<Boolean> = _darkMode.asStateFlow()

    private val _fontScale = MutableStateFlow(prefs.fontScale.coerceIn(0.85f, 1.5f))
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    private val _favorites = MutableStateFlow(prefs.favorites())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchHit>>(emptyList())
    val searchResults: StateFlow<List<SearchHit>> = _searchResults.asStateFlow()

    init {
        viewModelScope.launch {
            _books.value = repo.loadBooks()
            _loading.value = false
        }
    }

    fun navigate(screen: Screen) {
        _screen.value = screen
        if (screen != Screen.READER) translationJob?.cancel()
    }

    fun openBook(book: BibleBook, chapter: Int = 1) {
        _selectedBook.value = book
        _chapter.value = chapter.coerceIn(1, book.chapters.size)
        _screen.value = Screen.READER
        loadAndTranslateChapter()
    }

    fun openRef(ref: VerseRef) {
        val book = _books.value.firstOrNull { it.number == ref.book } ?: return
        openBook(book, ref.chapter)
    }

    fun setChapter(number: Int) {
        val book = _selectedBook.value ?: return
        _chapter.value = number.coerceIn(1, book.chapters.size)
        loadAndTranslateChapter()
    }

    fun setDisplayMode(mode: DisplayMode) {
        _displayMode.value = mode
        prefs.displayMode = mode.name
        if (mode != DisplayMode.EN) loadAndTranslateChapter()
    }

    fun setDarkMode(value: Boolean) {
        _darkMode.value = value
        prefs.darkMode = value
    }

    fun setFontScale(value: Float) {
        _fontScale.value = value.coerceIn(0.85f, 1.5f)
        prefs.fontScale = _fontScale.value
    }

    fun toggleFavorite(ref: VerseRef) {
        prefs.toggleFavorite(ref)
        _favorites.value = prefs.favorites()
    }

    fun speakVerse(verseNumber: Int) {
        val book = _selectedBook.value ?: return
        val chapter = book.chapters.firstOrNull { it.number == _chapter.value } ?: return
        val original = chapter.verses.firstOrNull { it.number == verseNumber }?.textEn.orEmpty()
        tts.speak(_translations.value[verseNumber] ?: original, "${book.number}_${_chapter.value}_$verseNumber")
    }

    fun speakCurrentChapter() {
        val book = _selectedBook.value ?: return
        val ch = book.chapters.firstOrNull { it.number == _chapter.value } ?: return
        val lines = ch.verses.map { verse -> _translations.value[verse.number] ?: verse.textEn }
        tts.speakChapter(lines)
    }

    fun stopSpeech() = tts.stop()

    fun search(query: String) {
        val q = query.trim()
        if (q.length < 2) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val books = _books.value
            val byRef = linkedMapOf<String, SearchHit>()

            books.forEach { book ->
                book.chapters.forEach { chapter ->
                    chapter.verses.forEach { verse ->
                        if (verse.textEn.contains(q, ignoreCase = true) && byRef.size < 100) {
                            val ref = VerseRef(book.number, chapter.number, verse.number)
                            byRef[ref.key] = SearchHit(ref, book.nameFr, verse.textEn, cache.get(ref))
                        }
                    }
                }
            }

            cache.searchFrench(q, 100).forEach { (ref, fr) ->
                if (byRef.size < 100 || byRef.containsKey(ref.key)) {
                    val found = repo.findVerse(ref)
                    if (found != null) {
                        val (book, verse) = found
                        byRef[ref.key] = SearchHit(ref, book.nameFr, verse.textEn, fr)
                    }
                }
            }

            withContext(Dispatchers.Main) {
                _searchResults.value = byRef.values.take(100)
            }
        }
    }

    fun favoriteHits(): List<SearchHit> = _favorites.value.mapNotNull { key ->
        val ref = VerseRef.fromKey(key) ?: return@mapNotNull null
        val found = repo.findVerse(ref) ?: return@mapNotNull null
        SearchHit(ref, found.first.nameFr, found.second.textEn, cache.get(ref))
    }.sortedWith(compareBy({ it.ref.book }, { it.ref.chapter }, { it.ref.verse }))

    private fun loadAndTranslateChapter() {
        translationJob?.cancel()
        val book = _selectedBook.value ?: return
        val chapterNumber = _chapter.value
        val chapter = book.chapters.firstOrNull { it.number == chapterNumber } ?: return

        translationJob = viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) { cache.getChapter(book.number, chapterNumber) }
            _translations.value = cached

            if (_displayMode.value == DisplayMode.EN) {
                _translationStatus.value = "Affichage anglais"
                return@launch
            }

            val missing = chapter.verses.filterNot { cached.containsKey(it.number) }
            if (missing.isEmpty()) {
                _translationStatus.value = "Traduction française disponible hors ligne"
                return@launch
            }

            try {
                _translationStatus.value = "Préparation du modèle de traduction français…"
                translator.prepareModel()
                _translationStatus.value = "Traduction ${cached.size}/${chapter.verses.size}…"

                val working = cached.toMutableMap()
                missing.forEachIndexed { index, verse ->
                    val fr = translator.translate(verse.textEn)
                    val ref = VerseRef(book.number, chapterNumber, verse.number)
                    withContext(Dispatchers.IO) { cache.put(ref, fr) }
                    working[verse.number] = fr
                    _translations.value = working.toMap()
                    _translationStatus.value = "Traduction ${cached.size + index + 1}/${chapter.verses.size}…"
                }
                _translationStatus.value = "Traduction française enregistrée hors ligne"
            } catch (e: Exception) {
                _translationStatus.value = "Traduction indisponible : ${e.localizedMessage ?: "connexion ou modèle requis"}"
            }
        }
    }

    override fun onCleared() {
        translationJob?.cancel()
        translator.close()
        tts.close()
        cache.close()
        super.onCleared()
    }
}
