package com.webmotion.bibleamplifiee.data

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser

class BibleRepository(private val context: Context) {
    @Volatile private var cachedBooks: List<BibleBook>? = null

    suspend fun loadBooks(): List<BibleBook> = withContext(Dispatchers.IO) {
        cachedBooks ?: parse().also { cachedBooks = it }
    }

    fun getCachedBooks(): List<BibleBook> = cachedBooks.orEmpty()

    fun findVerse(ref: VerseRef): Pair<BibleBook, BibleVerse>? {
        val book = cachedBooks?.firstOrNull { it.number == ref.book } ?: return null
        val chapter = book.chapters.firstOrNull { it.number == ref.chapter } ?: return null
        val verse = chapter.verses.firstOrNull { it.number == ref.verse } ?: return null
        return book to verse
    }

    private fun parse(): List<BibleBook> {
        val result = mutableListOf<BibleBook>()
        context.assets.open("EnglishAmplifiedBible.xml").use { input ->
            val parser = Xml.newPullParser().apply {
                setInput(input, "UTF-8")
            }

            var event = parser.eventType
            var testament = Testament.OLD
            var bookNumber = 0
            var chapterNumber = 0
            var chapters = mutableListOf<BibleChapter>()
            var verses = mutableListOf<BibleVerse>()

            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "testament" -> {
                            testament = if (parser.getAttributeValue(null, "name") == "New") Testament.NEW else Testament.OLD
                        }
                        "book" -> {
                            bookNumber = parser.getAttributeValue(null, "number")?.toIntOrNull() ?: 0
                            chapters = mutableListOf()
                        }
                        "chapter" -> {
                            chapterNumber = parser.getAttributeValue(null, "number")?.toIntOrNull() ?: 0
                            verses = mutableListOf()
                        }
                        "verse" -> {
                            val number = parser.getAttributeValue(null, "number")?.toIntOrNull() ?: 0
                            val text = parser.nextText().trim()
                            verses.add(BibleVerse(number, text))
                        }
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "chapter" -> chapters.add(BibleChapter(chapterNumber, verses.toList()))
                        "book" -> {
                            if (bookNumber in 1..66) {
                                result.add(
                                    BibleBook(
                                        number = bookNumber,
                                        nameFr = BookNames.french[bookNumber - 1],
                                        nameEn = BookNames.english[bookNumber - 1],
                                        testament = testament,
                                        chapters = chapters.toList()
                                    )
                                )
                            }
                        }
                    }
                }
                event = parser.next()
            }
        }
        return result
    }
}
